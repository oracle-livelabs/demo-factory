# Post-deployment regression check

`hightech-livestack-regression.mjs` is an operator-run regression check for a
deployed High Tech LiveStack. Terraform and cloud-init never execute it
automatically.

Run it from a workstation with Node.js 20 or later after the stack output
`first_boot_status_command` prints `RESOURCE_MANAGER_DEPLOYMENT_OK`:

```bash
node verification/hightech-livestack-regression.mjs \
  --base-url http://PUBLIC_IP:8505
```

The standard run checks the database-backed health endpoint, seeded data,
all ten High Tech scene APIs, global/regional/restricted VPD personas, native
JSON, Unified Audit, truthful ADB In-Memory declaration status, Vector Search,
SQL/PGQ, Spatial, both native duality views, all four OML models, the exact
eight-view Select AI profile, governed SHOWSQL/RUNSQL, nine adversarial SQL
classes, and reuse of an Oracle-created conversation ID across a two-turn Ask
High Tech follow-up. It creates short-lived Select AI conversation records.
Dataset status, invalid-upload handling, dry-run restore validation, and the
missing-command guard run by default without mutating business data.

For the full post-deployment run:

```bash
node verification/hightech-livestack-regression.mjs \
  --base-url http://PUBLIC_IP:8505 \
  --include-agent-chat \
  --include-restore
```

`--include-agent-chat` executes all three native advisory teams and a
two-turn `PRODUCT_OPERATIONS_AGENT` conversation; it adds four ordinary audit
records. `--include-restore` performs the guarded bundled-data restore and
polls its durable job through feature-ready completion, so it resets the demo
dataset. Use `--skip-chat` only for a bounded diagnostic run that intentionally
omits native Ask High Tech conversation acceptance.

`HIGHTECH_API_REGRESSION_OK` is the expected final marker. A nonzero exit code
or any `FAIL` line identifies the failing route.
