#!/usr/bin/env python3
"""Verify the static application payload and clean Resource Manager archive."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--archive", type=Path)
    return parser.parse_args()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def assert_safe_infos(archive: zipfile.ZipFile, label: str) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()
    casefolded: set[str] = set()

    bad_member = archive.testzip()
    if bad_member is not None:
        raise ValueError(f"{label} CRC/integrity failure at {bad_member}")

    for info in archive.infolist():
        name = info.filename
        path = PurePosixPath(name)
        if (
            not name
            or name.startswith("/")
            or "\\" in name
            or any(part in {"", ".", ".."} for part in path.parts)
        ):
            raise ValueError(f"{label} contains unsafe path: {name!r}")
        if name in seen:
            raise ValueError(f"{label} contains duplicate member: {name}")
        folded = name.casefold()
        if folded in casefolded:
            raise ValueError(f"{label} contains a case-colliding member: {name}")
        if info.flag_bits & 0x1:
            raise ValueError(f"{label} contains encrypted member: {name}")

        unix_mode = (info.external_attr >> 16) & 0xFFFF
        if stat.S_ISLNK(unix_mode):
            raise ValueError(f"{label} contains symbolic link: {name}")
        file_type = stat.S_IFMT(unix_mode)
        if file_type not in {0, stat.S_IFREG, stat.S_IFDIR}:
            raise ValueError(f"{label} contains special filesystem entry: {name}")

        seen.add(name)
        casefolded.add(folded)
        names.append(name)
    return names


def is_forbidden_member(name: str) -> bool:
    path = PurePosixPath(name.rstrip("/"))
    parts = [part.casefold() for part in path.parts]
    basename = parts[-1] if parts else ""

    forbidden_directories = {
        ".terraform",
        ".git",
        ".hg",
        ".svn",
        ".idea",
        ".vscode",
        "__macosx",
        "__pycache__",
        "node_modules",
        "coverage",
    }
    if any(part in forbidden_directories for part in parts):
        return True
    if (
        basename == ".ds_store"
        or basename == "ip.md"
        or (basename.startswith(".env") and basename != ".env.example")
        or basename.startswith("._")
    ):
        return True
    if basename.endswith(
        (
            ".pyc",
            ".pyo",
            ".swp",
            ".swo",
            ".log",
            ".pem",
            ".key",
            ".tfplan",
            ".tfvars",
            ".tfvars.json",
            ".tfstate",
            ".b64",
            ".p12",
            ".pfx",
            ".jks",
            "~",
        )
    ):
        return True
    if ".auto.tfvars" in basename or basename == "cwallet.sso":
        return True
    if ".tfstate." in basename or basename.endswith(".generated.zip"):
        return True
    if "wallet" in basename and basename.endswith(".zip"):
        return True
    return False


def scan_archive_text(
    archive: zipfile.ZipFile, names: list[str], label: str
) -> None:
    private_key = re.compile(
        rb"BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY"
    )
    local_model = re.compile(rb"ollama|llama3[.]2|11434", re.IGNORECASE)
    legacy_source_domain = re.compile(
        rb"\bfin" rb"ance\b|FIN" rb"ANCE_|"
        rb"manufacturing-livestack|MANUFACTURING_(?:SELECTAI|OPERATIONS)|"
        rb"manufacturing-(?:rm-bootstrap|selectai|application)|"
        rb"/opt/manufacturing-livestack|bootstrap-manufacturing|"
        rb"Ask Manufacturing Data",
        re.IGNORECASE,
    )

    for name in names:
        if (
            name.endswith("/")
            or name.casefold().endswith(".zip")
            or name.endswith("verification/check-resource-manager-package.py")
            or name.endswith("verification/check-selectai-platform-contract.sh")
        ):
            continue
        data = archive.read(name)
        if private_key.search(data):
            raise ValueError(f"{label} contains private-key material in {name}")
        member_parts = {
            part.casefold() for part in PurePosixPath(name).parts
        }
        runtime_local_model_scope = (
            "verification" not in member_parts
            and PurePosixPath(name).name.casefold() != "readme.md"
        )
        if runtime_local_model_scope and local_model.search(data):
            raise ValueError(
                f"{label} contains a forbidden local-model runtime reference in {name}"
            )
        if legacy_source_domain.search(data):
            raise ValueError(
                f"{label} contains a legacy source-domain reference in {name}"
            )


def validate_regression_route_contract(
    regression_path: Path,
    payload_archive: zipfile.ZipFile,
) -> None:
    """Bind the public regression targets to routes shipped in the payload."""

    if not regression_path.is_file():
        raise ValueError(
            f"High Tech public regression runner is missing: {regression_path}"
        )
    regression = regression_path.read_text(encoding="utf-8")

    forbidden_regression_fragments = {
        "Manufacturing production-signal namespace": "/api/production-signals",
        "Manufacturing work-order namespace": "/api/work-orders",
        "Manufacturing dashboard signal route": "/api/dashboard/signal-velocity",
        "Manufacturing dashboard value route": (
            "/api/dashboard/work-order-value-by-category"
        ),
        "Manufacturing graph route": "/api/graph/production-network",
        "Manufacturing demo status key": "hightech_production_signals",
        "Manufacturing work-order status key": "hightech_work_orders",
    }
    for label, fragment in forbidden_regression_fragments.items():
        if fragment in regression:
            raise ValueError(
                f"High Tech public regression still targets {label}"
            )

    required_regression_fragments = {
        "API health": "/api/health",
        "dataset status": "/api/demo/status",
        "native JSON": "/api/demo/native-json-readiness",
        "Unified Audit": "/api/demo/unified-audit-readiness",
        "disabled legacy mutation": "/api/demo/start",
        "dashboard summary": "/api/dashboard/summary",
        "dashboard product constraints": "/api/dashboard/trending-products",
        "dashboard product signals": "/api/dashboard/social-velocity",
        "dashboard commitment value": "/api/dashboard/revenue-by-category",
        "dashboard spatial demand": "/api/dashboard/demand-map",
        "truthful In-Memory": "/api/dashboard/inmemory",
        "product-signal feed": "/api/social/posts",
        "developer advocates": "/api/social/influencers",
        "vector readiness": "/api/social/vector-readiness",
        "product vector search": "/api/social/semantic-search",
        "signal vector search": "/api/social/post-search",
        "product details": "/api/products/",
        "VPD supply sites": "/api/fulfillment/centers",
        "Spatial readiness": "/api/fulfillment/spatial-readiness",
        "Spatial nearest": "/api/fulfillment/nearest",
        "native graph readiness": "/api/graph/readiness",
        "native graph network": "/api/graph/network/",
        "SQL/PGQ": "/api/graph/run-example",
        "customer commitments": "/api/orders/",
        "customer-commitment alias": "/api/service-requests/",
        "OML lifecycle": "/api/ml/models/status",
        "OML persistence": "/api/ml/persistence/status",
        "Select AI profile": "/api/selectai/profiles",
        "Select AI schema": "/api/selectai/schema-objects",
        "Select AI SHOWSQL": "/api/selectai/showsql",
        "Select AI RUNSQL": "/api/selectai/runsql",
        "Select AI chat": "/api/selectai/chat-mode",
        "native team catalog": "/api/agents/teams",
        "native team execution": "/api/agents/chat",
        "dataset lifecycle": "/api/import/dataset",
        "dataset validation": "/api/import/validate",
        "dataset restore validation": "/api/import/restore-demo/validate",
        "dataset restore execution": "/api/import/restore-demo",
        "dataset restore polling": "/api/import/status/",
    }
    for label, fragment in required_regression_fragments.items():
        if fragment not in regression:
            raise ValueError(
                f"High Tech public regression is missing {label}"
            )

    route_requirements = {
        "backend/server.js": [
            r"app[.]get\('/api/health'",
            r"app[.]use\('/api/dashboard'",
            r"app[.]use\('/api/social'",
            r"app[.]use\('/api/products'",
            r"app[.]use\('/api/fulfillment'",
            r"app[.]use\('/api/graph'",
            r"app[.]use\('/api/agents'",
            r"app[.]use\('/api/orders'",
            r"app[.]use\('/api/service-requests'",
            r"app[.]use\('/api/ml'",
            r"app[.]use\('/api/demo'",
            r"app[.]use\('/api/selectai'",
            r"app[.]use\('/api/import'",
        ],
        "backend/routes/demo.js": [
            r"router[.]get\('/status'",
            r"router[.]get\('/native-json-readiness'",
            r"router[.]get\('/unified-audit-readiness'",
            r"router[.]get\('/start'",
        ],
        "backend/routes/dashboard.js": [
            r"router[.]get\('/summary'",
            r"router[.]get\('/trending-products'",
            r"router[.]get\('/social-velocity'",
            r"router[.]get\('/revenue-by-category'",
            r"router[.]get\('/demand-map'",
            r"router[.]get\('/inmemory'",
        ],
        "backend/routes/social.js": [
            r"router[.]get\('/posts'",
            r"router[.]get\('/influencers'",
            r"router[.]get\('/vector-readiness'",
            r"router[.]post\('/semantic-search'",
            r"router[.]post\('/post-search'",
        ],
        "backend/routes/products.js": [
            r"router[.]get\('/'",
            r"router[.]get\('/:id'",
            r"router[.]get\('/:id/duality'",
        ],
        "backend/routes/fulfillment.js": [
            r"router[.]get\('/centers'",
            r"router[.]get\('/spatial-readiness'",
            r"router[.]get\('/nearest'",
        ],
        "backend/routes/graph.js": [
            r"router[.]get\('/readiness'",
            r"router[.]get\('/influencers'",
            r"router[.]get\('/network/:id'",
            r"router[.]post\('/run-example'",
        ],
        "backend/routes/orders.js": [
            r"router[.]get\('/'",
            r"router[.]get\('/:id'",
            r"router[.]get\('/:id/duality'",
        ],
        "backend/routes/ml.js": [
            r"router[.]get\('/models/status'",
            r"router[.]get\('/persistence/status'",
        ],
        "backend/routes/selectai.js": [
            r"router[.]get\('/profiles'",
            r"router[.]get\('/schema-objects'",
            r"router[.]post\('/chat-mode'",
            r"router[.]post\('/showsql'",
            r"router[.]post\('/runsql'",
        ],
        "backend/routes/agents.js": [
            r"router[.]post\('/chat'",
            r"router[.]get\('/teams'",
            r"router[.]get\('/tool-history'",
            r"router[.]get\('/team-history'",
        ],
        "backend/routes/import.js": [
            r"router[.]get\('/dataset'",
            r"router[.]post\('/validate'",
            r"router[.]post\('/restore-demo/validate'",
            r"router[.]post\('/restore-demo'",
            r"router[.]get\('/status/:jobId'",
        ],
    }
    for member, patterns in route_requirements.items():
        try:
            route_source = payload_archive.read(member).decode("utf-8")
        except KeyError as exc:
            raise ValueError(
                f"Application payload is missing route source {member}"
            ) from exc
        for pattern in patterns:
            if not re.search(pattern, route_source):
                raise ValueError(
                    f"Application payload route {member} does not satisfy {pattern}"
                )


def validate_hightech_database_contract(
    graph_runtime: str,
    duality_runtime: str,
    handoff_final: str,
) -> None:
    required_graph_patterns = {
        "Product Signal property graph": (
            r"CREATE\s+PROPERTY\s+GRAPH\s+tech_product_signal_network"
        ),
        "property-graph compilation": (
            r"ALTER\s+PROPERTY\s+GRAPH\s+tech_product_signal_network\s+COMPILE"
        ),
        "graph node view": (
            r"CREATE\s+OR\s+REPLACE\s+VIEW\s+developer_ecosystem_nodes_v"
        ),
        "graph edge view": (
            r"CREATE\s+OR\s+REPLACE\s+VIEW\s+developer_ecosystem_edges_v"
        ),
    }
    for label, pattern in required_graph_patterns.items():
        if not re.search(pattern, graph_runtime, re.IGNORECASE):
            raise ValueError(
                f"Application payload graph runtime is missing {label}"
            )

    required_duality_patterns = {
        "orders duality view": (
            r"CREATE\s+OR\s+REPLACE\s+JSON\s+RELATIONAL\s+DUALITY\s+"
            r"VIEW\s+orders_dv"
        ),
        "products duality view": (
            r"CREATE\s+OR\s+REPLACE\s+JSON\s+RELATIONAL\s+DUALITY\s+"
            r"VIEW\s+products_inventory_dv"
        ),
    }
    for label, pattern in required_duality_patterns.items():
        if not re.search(pattern, duality_runtime, re.IGNORECASE):
            raise ValueError(
                f"Application payload duality runtime is missing {label}"
            )

    compile_statements = [
        r"ALTER\s+VIEW\s+orders_dv\s+COMPILE\s*;",
        r"ALTER\s+VIEW\s+products_inventory_dv\s+COMPILE\s*;",
        r'ALTER\s+SYNONYM\s+"orders_dv"\s+COMPILE\s*;',
        r'ALTER\s+SYNONYM\s+"products_inventory_dv"\s+COMPILE\s*;',
    ]
    compile_offsets: list[int] = []
    for pattern in compile_statements:
        match = re.search(pattern, duality_runtime, re.IGNORECASE)
        if not match:
            raise ValueError(
                "Application payload duality runtime is missing the "
                f"ADB/VPD compile step {pattern}"
            )
        compile_offsets.append(match.start())
    if compile_offsets != sorted(compile_offsets):
        raise ValueError(
            "Application payload duality runtime must compile both target "
            "views before their quoted lowercase collection synonyms"
        )

    required_duality_validity_patterns = {
        "valid read-only duality metadata": (
            r"FROM\s+user_json_duality_views.*?"
            r"view_name\s+IN\s*\(\s*'ORDERS_DV'\s*,\s*"
            r"'PRODUCTS_INVENTORY_DV'\s*\).*?"
            r"status\s*=\s*'VALID'.*?"
            r"read_only\s*=\s*TRUE.*?"
            r"allow_insert\s*=\s*FALSE.*?"
            r"allow_update\s*=\s*FALSE.*?"
            r"allow_delete\s*=\s*FALSE"
        ),
        "valid lowercase collection synonyms": (
            r"FROM\s+user_objects.*?"
            r"object_type\s*=\s*'SYNONYM'.*?"
            r"object_name\s+IN\s*\(\s*'orders_dv'\s*,\s*"
            r"'products_inventory_dv'\s*\).*?"
            r"status\s*=\s*'VALID'"
        ),
        "exact duality and synonym counts": (
            r"l_valid_read_only_views\s*<>\s*2\s+OR\s+"
            r"l_valid_synonyms\s*<>\s*2"
        ),
    }
    for label, pattern in required_duality_validity_patterns.items():
        if not re.search(
            pattern,
            duality_runtime,
            re.IGNORECASE | re.DOTALL,
        ):
            raise ValueError(
                f"Application payload duality runtime is missing {label}"
            )

    required_handoff_patterns = {
        "administrator VPD context": (
            r"hightech_security_pkg[.]set_user_context"
            r"\(\s*'admin_jess'\s*\)"
        ),
        "High Tech data acceptance marker": (
            r"HIGHTECH_HANDOFF_DATA_ACCEPTANCE_OK"
        ),
    }
    for label, pattern in required_handoff_patterns.items():
        if not re.search(pattern, handoff_final, re.IGNORECASE):
            raise ValueError(
                f"Application payload final handoff is missing {label}"
            )


def validate_native_sql_tool_contract(native_bootstrap: str) -> None:
    object_list_match = re.search(
        r"'object_list'\s+VALUE\s+JSON_ARRAY\((.*?)\)"
        r"\s+FORMAT\s+JSON\s*,\s*'object_list_mode'",
        native_bootstrap,
        re.IGNORECASE | re.DOTALL,
    )
    if not object_list_match:
        raise ValueError(
            "Application payload native bootstrap is missing its Select AI "
            "object_list"
        )
    object_list = object_list_match.group(1)
    object_names = re.findall(
        r"'name'\s+VALUE\s+'([^']+)'",
        object_list,
        re.IGNORECASE,
    )
    expected_objects = [
        "TECH_PORTFOLIOS_V",
        "HIGHTECH_PRODUCTS_V",
        "PRODUCT_SIGNALS_V",
        "DEVELOPER_ADVOCATES_V",
        "PRODUCT_SIGNAL_MATCHES_V",
        "SOLUTION_ORDERS_V",
        "PRODUCT_CAPACITY_V",
        "FULFILLMENT_ROUTES_V",
    ]
    if object_names != expected_objects:
        raise ValueError(
            "Application payload native bootstrap Select AI object_list is "
            f"not the exact eight-view High Tech contract: {object_names}"
        )
    owners = re.findall(
        r"'owner'\s+VALUE\s+'([^']+)'",
        object_list,
        re.IGNORECASE,
    )
    if owners != ["APP_USER"] * len(expected_objects):
        raise ValueError(
            "Application payload native bootstrap object_list must bind all "
            "eight views to APP_USER"
        )
    for excluded_object in {
        "SEERTECH_AGENT_ACTIONS_V",
        "SIGNAL_EMBEDDINGS",
    }:
        if excluded_object in object_list.upper():
            raise ValueError(
                "Application payload native bootstrap exposes excluded "
                f"Select AI object {excluded_object}"
            )
    if not re.search(
        r"'object_list_mode'\s+VALUE\s+'all'.*?"
        r"'enforce_object_list'\s+VALUE\s+'true'\s+FORMAT\s+JSON",
        native_bootstrap,
        re.IGNORECASE | re.DOTALL,
    ):
        raise ValueError(
            "Application payload native bootstrap does not enforce its exact "
            "Select AI object_list"
        )

    worker_blocks = [
        block
        for block in re.findall(
            r"(?ms)^[ \t]{2}create_worker\(\s*\n"
            r"(.*?)^[ \t]{2}\);",
            native_bootstrap,
            re.IGNORECASE,
        )
        if "p_agent_name" in block.lower() and "=>" in block
    ]
    worker_contract = []
    for block in worker_blocks:
        fields = []
        for field in ("p_agent_name", "p_task_name", "p_team_name"):
            match = re.search(
                rf"\b{field}\s*=>\s*'([^']+)'",
                block,
                re.IGNORECASE,
            )
            if not match:
                raise ValueError(
                    "Application payload native bootstrap has a malformed "
                    f"create_worker {field}"
                )
            fields.append(match.group(1))
        worker_contract.append(tuple(fields))
    expected_workers = [
        (
            "HT_TECH_SIGNAL_WORKER",
            "HT_TECH_SIGNAL_TASK",
            "TECH_SIGNAL_AGENT",
        ),
        (
            "HT_PRODUCT_AVAILABILITY_WORKER",
            "HT_PRODUCT_AVAILABILITY_TASK",
            "PRODUCT_AVAILABILITY_AGENT",
        ),
        (
            "HT_PRODUCT_OPERATIONS_WORKER",
            "HT_PRODUCT_OPERATIONS_TASK",
            "PRODUCT_OPERATIONS_AGENT",
        ),
    ]
    if worker_contract != expected_workers:
        raise ValueError(
            "Application payload native bootstrap worker/task/team contract "
            f"is inconsistent: {worker_contract}"
        )

    registration_patterns = {
        "SQL tool type": r"'tool_type'\s+VALUE\s+'SQL'",
        "Select AI profile binding": (
            r"'profile_name'\s+VALUE\s+'HIGHTECH_SELECTAI_V1'"
        ),
        "High Tech SQL tool registration": (
            r"DBMS_CLOUD_AI_AGENT[.]CREATE_TOOL\(\s*"
            r"tool_name\s*=>\s*'HIGHTECH_READONLY_SQL_TOOL'"
        ),
        "primary team descriptor": (
            r"DBMS_CLOUD_AI_AGENT[.]DESCRIBE_TEAM"
            r"\(\s*'PRODUCT_OPERATIONS_AGENT'\s*\)"
        ),
    }
    for label, pattern in registration_patterns.items():
        if not re.search(pattern, native_bootstrap, re.DOTALL):
            raise ValueError(
                f"Application payload native bootstrap is missing {label}"
            )

    marker_names = {
        "HIGHTECH_NATIVE_AI_SQL_GATE_OK",
        "HIGHTECH_NATIVE_AI_AGENT_TASKS_TOOL_FREE_OK",
        "HIGHTECH_NATIVE_AI_CHAT_OK",
        "HIGHTECH_NATIVE_AI_SHOWSQL_OK",
        "HIGHTECH_NATIVE_AI_RUNSQL_OK",
        "HIGHTECH_NATIVE_AI_AGENT_TOOL_OK",
        "HIGHTECH_NATIVE_AI_AGENT_OK",
        "HIGHTECH_NATIVE_AI_ACCEPTANCE_OK",
    }
    missing_markers = sorted(
        marker for marker in marker_names if marker not in native_bootstrap
    )
    if missing_markers:
        raise ValueError(
            "Application payload native bootstrap is missing acceptance "
            "marker(s): " + ", ".join(missing_markers)
        )

    acceptance_start = native_bootstrap.find(
        "HIGHTECH_NATIVE_AI_SQL_GATE_OK"
    )
    if acceptance_start < 0:
        raise ValueError(
            "Application payload native bootstrap is missing the SQL gate"
        )
    acceptance_tail = native_bootstrap[acceptance_start:]
    stale_acceptance_objects = {
        "HIGHTECH_SUPPLIERS",
        "HIGHTECH_WORK_ORDERS",
        "HIGHTECH_PARTS_V",
        "HT_PRODUCTION_SIGNAL_TASK",
        "HT_CAPACITY_ROUTE_TASK",
        "HT_WORK_ORDER_TASK",
        "HIGHTECH_OPERATIONS_TEAM",
    }
    for stale_name in stale_acceptance_objects:
        if stale_name in acceptance_tail:
            raise ValueError(
                "Application payload native acceptance still references "
                f"stale object {stale_name}"
            )
    if "DBMS_CLOUD_AI_AGENT.RUN_TEAM(" in acceptance_tail:
        raise ValueError(
            "Application payload must keep model-directed RUN_TEAM out of "
            "bounded Apply acceptance; the public live regression owns it"
        )
    if "DBMS_CLOUD_AI.CREATE_CONVERSATION(" in acceptance_tail:
        raise ValueError(
            "Application payload must keep native two-turn conversation calls "
            "out of bounded Apply acceptance; the public live regression owns them"
        )

    probe_start = native_bootstrap.find(
        "l_agent_tool := DBMS_CLOUD_AI_AGENT.RUN_TOOL("
    )
    probe_end = native_bootstrap.find(
        "DBMS_OUTPUT.PUT_LINE('HIGHTECH_NATIVE_AI_AGENT_TOOL_OK');",
        probe_start,
    )
    if probe_start < 0 or probe_end < 0:
        raise ValueError(
            "Application payload is missing the native SQL RUN_TOOL probe"
        )
    probe = native_bootstrap[probe_start:probe_end]
    input_end = probe.find("\n  );")
    if input_end < 0:
        raise ValueError(
            "Application payload native SQL RUN_TOOL call is malformed"
        )
    probe_input = probe[:input_end]

    required_probe_patterns = {
        "High Tech SQL tool name": (
            r"tool_name\s*=>\s*'HIGHTECH_READONLY_SQL_TOOL'"
        ),
        "execution-derived row marker query": (
            r"SELECT ''HIGHTECH_SQL_TOOL_ROWS_''\s*[|][|].*"
            r"TO_CHAR\(COUNT\(\*\),\s*''FM9999999990''\).*"
            r"FROM HIGHTECH_PRODUCTS_V"
        ),
        "RUNSQL action": r'"ACTION":"RUNSQL"',
        "non-NULL result guard": r"l_agent_tool IS NULL",
        "non-empty result guard": (
            r"DBMS_LOB[.]GETLENGTH\(l_agent_tool\)\s*=\s*0"
        ),
        "whole-CLOB execution marker": (
            r"DBMS_LOB[.]INSTR\(\s*UPPER\(l_agent_tool\),\s*"
            r"'HIGHTECH_SQL_TOOL_ROWS_31',\s*1,\s*1\s*\)\s*=\s*0"
        ),
    }
    for label, pattern in required_probe_patterns.items():
        target = (
            probe_input
            if label in {
                "High Tech SQL tool name",
                "execution-derived row marker query",
                "RUNSQL action",
            }
            else probe
        )
        if not re.search(pattern, target, re.DOTALL):
            raise ValueError(
                "Application payload native SQL tool probe is missing "
                f"{label}"
            )

    if "HIGHTECH_SQL_TOOL_ROWS_31" in probe_input:
        raise ValueError(
            "Application payload native SQL tool input contains its expected "
            "execution result and can false-pass by echoing"
        )
    if "TOTAL_ROWS" in probe:
        raise ValueError(
            "Application payload native SQL tool probe still relies on a "
            "display alias"
        )
    if re.search(
        r"DBMS_LOB[.]SUBSTR\(\s*l_agent_tool", probe, re.IGNORECASE
    ):
        raise ValueError(
            "Application payload native SQL tool probe truncates its result"
        )


def validate_admin_password_transport_contract(adb_bootstrap: str) -> None:
    """Require secret-free drivers and SQLcl startup password input."""

    if re.search(r"(?mi)^[ \t]*CONNECT[ \t]+ADMIN\b", adb_bootstrap):
        raise ValueError(
            "Application payload must not place an ADMIN login in a SQL "
            "driver; SQLcl startup must own the password prompt"
        )
    if re.search(
        r"(?m)^[ \t]*\$\{ADB_ADMIN_PASSWORD\}[ \t]*$", adb_bootstrap
    ):
        raise ValueError(
            "Application payload must not write the ADMIN password into a "
            "SQL driver"
        )

    required_transport_patterns = {
        "connection-mode argument": (
            r'local[ \t]+connection_mode="\$\{5:-nolog\}"'
        ),
        "password first on stdin": (
            r"printf[ \t]+'%s\\n'[ \t]+\"\$\{ADB_ADMIN_PASSWORD\}\""
        ),
        "driver after password": r'cat[ \t]+\"\$\{driver\}\"',
        "secret-free SQLcl startup logon": (
            r'sql[ \t]+-S[ \t]+-L[ \t]+-cloudconfig[ \t]+'
            r'\"\$\{WALLET_ARCHIVE\}\"[ \t]+'
            r'(?:\\[ \t]*\r?\n[ \t]*)?'
            r'\"ADMIN@\$\{ADB_CONNECT_STRING\}\"'
        ),
    }
    for label, pattern in required_transport_patterns.items():
        if not re.search(pattern, adb_bootstrap):
            raise ValueError(
                "Application payload ADB bootstrap is missing " + label
            )

    password_pipe = re.search(
        r"\{[ \t\r\n]*"
        r"printf[ \t]+'%s\\n'[ \t]+\"\$\{ADB_ADMIN_PASSWORD\}\""
        r"[ \t\r\n]+cat[ \t]+\"\$\{driver\}\"[ \t\r\n]*"
        r"\}[ \t]*\|[ \t\r\n]*"
        r"sql[ \t]+-S[ \t]+-L[ \t]+-cloudconfig[ \t]+"
        r'\"\$\{WALLET_ARCHIVE\}\"[ \t]+'
        r'(?:\\[ \t]*\r?\n[ \t]*)?'
        r'\"ADMIN@\$\{ADB_CONNECT_STRING\}\"',
        adb_bootstrap,
    )
    if not password_pipe:
        raise ValueError(
            "Application payload must pipe the ADMIN password before the "
            "secret-free SQL driver into SQLcl startup logon"
        )

    admin_phases = re.findall(
        r'run_sql_phase[ \t]+\"([^\"]+)\"[ \t]+\"[^\"]+\"'
        r'[ \t]+\\[ \t]*\r?\n[ \t]*\"[^\"]+\"[ \t]+'
        r'\"none\"[ \t]+\"admin_password_stdin\"[ \t]*$',
        adb_bootstrap,
        re.MULTILINE,
    )
    if admin_phases != ["bootstrap", "security"]:
        raise ValueError(
            "Application payload must bind startup password input only to "
            "the bootstrap and security ADMIN phases"
        )

    if re.search(
        r"(?mi)^(?:[^\r\n]*\b(?:sql|connect)\b[^\r\n]*)"
        r"\$\{ADB_ADMIN_PASSWORD\}",
        adb_bootstrap,
    ):
        raise ValueError(
            "Application payload must not expose the ADMIN password in a "
            "SQLcl command or CONNECT statement"
        )


def validate_payload(
    payload_path: Path,
    regression_path: Path,
) -> tuple[str, int]:
    if not payload_path.is_file():
        raise ValueError(f"Static application payload is missing: {payload_path}")

    with zipfile.ZipFile(payload_path) as archive:
        names = assert_safe_infos(archive, "application payload")
        forbidden = [name for name in names if is_forbidden_member(name)]
        if forbidden:
            raise ValueError(
                "Application payload contains forbidden artifact: " + forbidden[0]
            )
        nested = [
            name
            for name in names
            if not name.endswith("/") and name.casefold().endswith(".zip")
        ]
        if nested:
            raise ValueError(
                "Application payload contains an unexpected nested ZIP: " + nested[0]
            )
        required = {
            "Containerfile",
            "compose.yml",
            "package.json",
            "package-lock.json",
            "frontend/package.json",
            "deployment/bootstrap-hightech-adb.sh",
            "deployment/hightech-handoff-final.sql",
            "deployment/hightech-native-ai-bootstrap.sql",
            "deployment/hightech-platform-handoff-loader.sql",
            "db/schema/10_developer_ecosystem_graph.sql",
            "db/schema/18_hightech_duality_runtime.sql",
            "backend/server.js",
            "backend/routes/demo.js",
            "backend/routes/dashboard.js",
            "backend/routes/social.js",
            "backend/routes/products.js",
            "backend/routes/fulfillment.js",
            "backend/routes/graph.js",
            "backend/routes/orders.js",
            "backend/routes/ml.js",
            "backend/routes/selectai.js",
            "backend/routes/agents.js",
            "backend/routes/import.js",
        }
        missing = sorted(required.difference(names))
        if missing:
            raise ValueError(
                "Application payload is missing required root member(s): "
                + ", ".join(missing)
            )
        if any(name.startswith("application/") for name in names):
            raise ValueError(
                "Application payload must be rootless; found application/ prefix"
            )
        scan_archive_text(archive, names, "application payload")
        validate_regression_route_contract(regression_path, archive)
        validate_hightech_database_contract(
            archive.read(
                "db/schema/10_developer_ecosystem_graph.sql"
            ).decode("utf-8"),
            archive.read(
                "db/schema/18_hightech_duality_runtime.sql"
            ).decode("utf-8"),
            archive.read(
                "deployment/hightech-handoff-final.sql"
            ).decode("utf-8"),
        )
        validate_native_sql_tool_contract(
            archive.read(
                "deployment/hightech-native-ai-bootstrap.sql"
            ).decode("utf-8")
        )
        validate_admin_password_transport_contract(
            archive.read(
                "deployment/bootstrap-hightech-adb.sh"
            ).decode("utf-8")
        )

        return sha256_file(payload_path), sum(
            not name.endswith("/") for name in names
        )


def load_build_contract(source_root: Path):
    scripts_dir = source_root / "scripts"
    sys.path.insert(0, str(scripts_dir))
    try:
        import build_resource_manager_package as build_contract
        import create_clean_zip as clean_zip
    finally:
        sys.path.pop(0)
    return build_contract, clean_zip


def expected_entries(
    source: Path,
    output: Path,
    excludes: tuple[str, ...],
    clean_zip,
) -> tuple[dict[str, Path], set[str]]:
    namespace = argparse.Namespace(
        contents_only=True,
        root_name=None,
        exclude=list(excludes),
        no_default_excludes=False,
        reproducible=True,
    )
    entries, skipped = clean_zip.collect_paths(source, output, namespace)
    if any(item.startswith("symlink ") for item in skipped):
        raise ValueError("Source parity encountered a skipped symlink")
    files = {name: path for path, name, is_dir in entries if not is_dir}
    all_names = {name for _, name, _ in entries}
    return files, all_names


def assert_source_parity(
    archive_path: Path,
    source: Path,
    output: Path,
    excludes: tuple[str, ...],
    clean_zip,
    label: str,
) -> None:
    expected_files, expected_names = expected_entries(
        source, output, excludes, clean_zip
    )
    with zipfile.ZipFile(archive_path) as archive:
        actual_names = set(archive.namelist())
        if actual_names != expected_names:
            missing = sorted(expected_names - actual_names)
            extra = sorted(actual_names - expected_names)
            raise ValueError(
                f"{label} source parity mismatch; missing={missing[:3]}, "
                f"extra={extra[:3]}"
            )
        for name, path in expected_files.items():
            actual_hash = sha256_bytes(archive.read(name))
            expected_hash = sha256_file(path)
            if actual_hash != expected_hash:
                raise ValueError(f"{label} content drift at {name}")


def validate_terraform_static_contract(source_root: Path) -> None:
    terraform_text = "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted(source_root.glob("*.tf"))
    )
    required_patterns = {
        "static payload path": r"payload/hightech-application[.]zip",
        "High Tech Select AI profile": r'HIGHTECH_SELECTAI_V1',
        "High Tech agent teams": r'TECH_SIGNAL_AGENT,PRODUCT_AVAILABILITY_AGENT,PRODUCT_OPERATIONS_AGENT',
        "plan-time payload hash": r"filesha256[(]local[.]application_payload_path[)]",
        "direct object source": r"source\s*=\s*local[.]application_payload_path",
        "hash-addressed object": r"local[.]application_payload_sha256",
        "digest-keyed payload resource": r"for_each\s*=\s*toset[(]\[local[.]application_payload_sha256\]\)",
        "immutable payload object path": r'object\s*=\s*"application/payloads/\$\{each[.]key\}[.]zip"',
        "digest-keyed payload reference": r"oci_objectstorage_object[.]application\[local[.]application_payload_sha256\][.]object",
        "High Tech bootstrap callback format": r"hightech-rm-bootstrap/v1",
        "High Tech public-key callback format": r"hightech-selectai-api-key-public/v1",
        "High Tech activation callback format": r"hightech-selectai-api-key-activation/v1",
        "gzip cloud-init": r"base64gzip[(]local[.]application_cloud_init[)]",
        "metadata budget": r"application_instance_metadata_budget_bytes\s*=\s*30000",
        "metadata precondition": r"application_metadata_size_bytes\s*<=\s*local[.]application_instance_metadata_budget_bytes",
        "Compute delivery trigger": r'filesha256[(]"\$\{path[.]module\}/compute-app[.]tf"[)]',
        "Object Storage delivery trigger": r'filesha256[(]"\$\{path[.]module\}/object-storage[.]tf"[)]',
        "identity-domain input": r'variable\s+"identity_domain_ocid"',
        "validated OCI provider": r'version\s*=\s*"=\s*8[.]25[.]0"',
        "validated Random provider": r'version\s*=\s*"=\s*3[.]9[.]0"',
        "identity-domain lookup": r'data\s+"oci_identity_domain"\s+"selected"',
        "self-service key inventory": r'data\s+"oci_identity_domains_my_api_keys"\s+"current"',
        "self-service API-key resource": r'resource\s+"oci_identity_domains_my_api_key"\s+"select_ai"',
        "Identity Domains API-key schema": r"urn:ietf:params:scim:schemas:oracle:idcs:apikey",
        "API-key capacity guard": r"total_results\s*<\s*3",
        "Plan-known key owner token": r"selectai_api_key_owner_token\s*=\s*substr[(]sha256[(]jsonencode",
        "current-user binding": r"self[.]user\[0\][.]ocid\s*==\s*var[.]current_user_ocid",
        "identity-domain binding": r"self[.]domain_ocid\s*==\s*var[.]identity_domain_ocid",
    }
    for label, pattern in required_patterns.items():
        if not re.search(pattern, terraform_text):
            raise ValueError(f"Terraform is missing {label}")
    if re.search(r"\b(?:data|resource)\s+\"archive_file\"", terraform_text):
        raise ValueError("Terraform still creates the application ZIP at job time")
    if "hashicorp/archive" in terraform_text:
        raise ValueError("Terraform still declares the archive provider")
    if re.search(r"base64encode\s*[(]\s*templatefile\s*[(]", terraform_text):
        raise ValueError("Terraform still ships plain-Base64 cloud-init")
    if re.search(r'resource\s+"oci_identity_api_key"', terraform_text):
        raise ValueError("Terraform still uses the legacy IAM API-key resource")
    if re.search(
        r"selectai_api_key_description\s*=.*random_id", terraform_text
    ):
        raise ValueError(
            "Terraform defers the API-key capacity decision past Plan"
        )


def validate_outer_archive(
    archive_path: Path, payload_path: Path
) -> tuple[str, int]:
    with zipfile.ZipFile(archive_path) as archive:
        names = assert_safe_infos(archive, "Resource Manager archive")
        forbidden = [name for name in names if is_forbidden_member(name)]
        if forbidden:
            raise ValueError(
                "Resource Manager archive contains forbidden artifact: "
                + forbidden[0]
            )
        required = {
            "main.tf",
            "schema.yaml",
            "payload/hightech-application.zip",
            "verification/check-compute-metadata-budget.py",
            "verification/hightech-livestack-regression.mjs",
        }
        missing = sorted(required.difference(names))
        if missing:
            raise ValueError(
                "Resource Manager archive is missing root contract member(s): "
                + ", ".join(missing)
            )
        if any(name.startswith("application/") for name in names):
            raise ValueError(
                "Resource Manager archive contains duplicate raw application source"
            )
        nested = [
            name
            for name in names
            if not name.endswith("/") and name.casefold().endswith(".zip")
        ]
        if nested != ["payload/hightech-application.zip"]:
            raise ValueError(
                "Resource Manager archive must contain exactly one approved "
                f"nested ZIP; found {nested}"
            )
        embedded_hash = sha256_bytes(
            archive.read("payload/hightech-application.zip")
        )
        if embedded_hash != sha256_file(payload_path):
            raise ValueError(
                "Embedded application payload differs from the verified source payload"
            )
        scan_archive_text(archive, names, "Resource Manager archive")
        return sha256_file(archive_path), sum(
            not name.endswith("/") for name in names
        )


def main() -> int:
    args = parse_args()
    source_root = args.source_root.expanduser().resolve()
    payload_path = source_root / "payload" / "hightech-application.zip"
    regression_path = (
        source_root
        / "verification"
        / "hightech-livestack-regression.mjs"
    )

    validate_terraform_static_contract(source_root)
    payload_hash, payload_files = validate_payload(
        payload_path,
        regression_path,
    )

    application_root = source_root / "application"
    if application_root.is_dir():
        build_contract, clean_zip = load_build_contract(source_root)
        assert_source_parity(
            payload_path,
            application_root,
            payload_path,
            build_contract.PAYLOAD_EXCLUDES,
            clean_zip,
            "application payload",
        )
        print("PASS: application payload exactly matches clean source allowlist")
    else:
        print(
            "INFO: raw application source is intentionally absent; "
            "payload source-parity check skipped"
        )

    print(
        f"PASS: static application payload is clean "
        f"({payload_files} files, sha256={payload_hash})"
    )

    if args.archive:
        archive_path = args.archive.expanduser().resolve()
        archive_hash, archive_files = validate_outer_archive(
            archive_path, payload_path
        )
        if application_root.is_dir():
            build_contract, clean_zip = load_build_contract(source_root)
            assert_source_parity(
                archive_path,
                source_root,
                archive_path,
                build_contract.OUTER_EXCLUDES,
                clean_zip,
                "Resource Manager archive",
            )
            print(
                "PASS: Resource Manager archive exactly matches clean source allowlist"
            )
        print(
            f"PASS: Resource Manager archive is clean "
            f"({archive_files} files, sha256={archive_hash})"
        )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        print(f"package verification failed: {exc}", file=sys.stderr)
        raise SystemExit(2)
