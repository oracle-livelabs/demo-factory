output "application_url" {
  description = "Public Peak Gear AI Lakehouse URL. Apply succeeds only after the app and required services are ready."
  value       = "http://${oci_core_instance.application.public_ip}:${local.application_port}/"
}

output "application_health_url" {
  description = "Peak Gear application health endpoint."
  value       = "http://${oci_core_instance.application.public_ip}:${local.application_port}/api/health"
}

output "application_ssh_command" {
  description = "SSH command for the application VM."
  value       = "ssh opc@${oci_core_instance.application.public_ip}"
}

output "first_boot_status_command" {
  description = "Display cloud-init and the recorded deployment state."
  value       = "ssh opc@${oci_core_instance.application.public_ip} 'sudo cloud-init status --wait; result=$?; sudo cat /opt/peakgear-livestack/deployment-status.txt 2>/dev/null || true; exit $result'"
}

output "bootstrap_log_command" {
  description = "Display the Peak Gear bootstrap log after an Apply failure."
  value       = "ssh opc@${oci_core_instance.application.public_ip} 'sudo tail -n 300 /var/log/peakgear-livestack-bootstrap.log'"
}

output "installer_log_command" {
  description = "Display both Peak Gear installer logs, including the registry-login console output."
  value       = "ssh opc@${oci_core_instance.application.public_ip} 'sudo tail -n 300 /opt/peakgear-livestack/installer-console.log 2>/dev/null || true; tail -n 300 /home/opc/inst.log 2>/dev/null || true'"
}

output "database_bootstrap_diagnostics_command" {
  description = "Display ADB wallet and loader service state plus the current ADB loader log."
  value       = "ssh opc@${oci_core_instance.application.public_ip} 'XDG_RUNTIME_DIR=/run/user/$(id -u) DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/$(id -u)/bus systemctl --user --no-pager --full status adb-wallet.service adb-load.service || true; tail -n 300 /home/opc/ingestion/logs/adb-load.log 2>/dev/null || true'"
}

output "autonomous_database_name" {
  description = "Autonomous Database name."
  value       = oci_database_autonomous_database.application.db_name
}

output "autonomous_database_ocid" {
  description = "Autonomous Database OCID."
  value       = oci_database_autonomous_database.application.id
}

output "autonomous_database_service" {
  description = "ADB wallet service used by Peak Gear."
  value       = local.adb_service_name
}

output "peakgear_database_user" {
  description = "Peak Gear application schema."
  value       = "PG"
}

output "peakgear_database_password" {
  description = "Password used by the Peak Gear PG schema. Treat Resource Manager state as sensitive."
  value       = local.adb_admin_password
  sensitive   = true
}

output "autonomous_database_admin_password" {
  description = "Configured ADMIN password. Treat Resource Manager state as sensitive."
  value       = local.adb_admin_password
  sensitive   = true
}

output "ggsa_url" {
  description = "GoldenGate Stream Analytics URL. It is reachable only when a trusted tools CIDR was supplied."
  value       = "https://${oci_core_instance.application.public_ip}:${local.ggsa_https_port}/osa/index.html"
}

output "goldengate_studio_url" {
  description = "GoldenGate Studio URL. It is reachable only when a trusted tools CIDR was supplied."
  value       = "https://${oci_core_instance.application.public_ip}:${local.goldengate_port}/"
}

output "gravitino_url" {
  description = "Gravitino REST endpoint. It is reachable only when a trusted tools CIDR was supplied."
  value       = "http://${oci_core_instance.application.public_ip}:${local.gravitino_port}/iceberg/v1/config"
}

output "tool_access_note" {
  description = "Whether optional administration endpoints are exposed through the NSG."
  value       = trimspace(var.tools_ingress_cidr) == "" ? "Optional GGSA, GoldenGate, and Gravitino ports are private." : "Optional tool ports are restricted to ${var.tools_ingress_cidr}."
}

output "object_storage_bucket_name" {
  description = "Private stack-owned bucket used for the wallet, status callback, uploads, and Iceberg data."
  value       = oci_objectstorage_bucket.lakehouse.name
}

output "first_boot_note" {
  description = "What a successful Resource Manager Apply means."
  value       = "Apply waits for ADB data loading, the Peak Gear health endpoint, Gravitino, GGSA, and GoldenGate. A successful Apply means RESOURCE_MANAGER_DEPLOYMENT_OK was reached."
}
