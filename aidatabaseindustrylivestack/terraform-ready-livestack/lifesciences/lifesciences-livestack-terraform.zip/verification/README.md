# Package verification

check-compute-metadata-budget.py and check-resource-manager-package.py run
automatically from the package builder.
It verifies that the Resource Manager upload ZIP is rootless, has one clean
nested application payload, excludes local credentials/build state, and
contains the required Terraform/bootstrap contract.
