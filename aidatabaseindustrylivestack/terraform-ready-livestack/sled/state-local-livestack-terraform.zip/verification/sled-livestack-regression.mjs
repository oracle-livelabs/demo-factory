#!/usr/bin/env node
/*
 * Safe operator-run regression for a deployed SLED LiveStack.
 *
 * The default suite only reads health, metadata, and seeded demo data. Adding
 * --include-ai sends one read-only Ask Data request. Adding
 * --include-agent-chat sends one advisory Agent Console request, which can add
 * a proposed audit entry. Neither option imports, restores, or changes the
 * SLED dataset.
 *
 * Usage:
 *   node sled-livestack-regression.mjs --base-url http://host:8505
 *   node sled-livestack-regression.mjs --base-url http://host:8505 --include-ai
 *   node sled-livestack-regression.mjs --base-url http://host:8505 --include-agent-chat
 */

import assert from 'node:assert/strict';
import process from 'node:process';

function argument(name, fallback = undefined) {
  const index = process.argv.indexOf(name);
  return index === -1 ? fallback : process.argv[index + 1] || fallback;
}

const rawBaseUrl = argument('--base-url');
if (!rawBaseUrl) {
  console.error('Usage: node sled-livestack-regression.mjs --base-url http://host:8505 [--include-ai] [--include-agent-chat]');
  process.exit(2);
}

const baseUrl = rawBaseUrl.replace(/\/+$/, '');
const origin = new URL(baseUrl).origin;
const timeoutMs = Number(argument('--timeout-ms', '120000'));
const agentTimeoutMs = Number(argument('--agent-timeout-ms', '300000'));
const runAi = process.argv.includes('--include-ai') || process.argv.includes('--include-agent-chat');
const runAgentChat = process.argv.includes('--include-agent-chat');
const results = [];
let sessionCookie = '';

function value(object, ...keys) {
  return keys.map((key) => object?.[key]).find((candidate) => candidate !== undefined && candidate !== null);
}

function nonEmptyArray(payload, label) {
  assert.ok(Array.isArray(payload), `${label} must be an array`);
  assert.ok(payload.length > 0, `${label} must not be empty`);
  return payload;
}

function responseCookies(response) {
  const cookies = typeof response.headers.getSetCookie === 'function'
    ? response.headers.getSetCookie()
    : [response.headers.get('set-cookie')].filter(Boolean);
  return cookies.map((cookie) => cookie.split(';', 1)[0]).filter(Boolean).join('; ');
}

async function request(label, path, {
  method = 'GET', body, timeout = timeoutMs, headers = {}, expectedStatus = 200,
} = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      method,
      headers: {
        accept: 'application/json',
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...(sessionCookie ? { cookie: sessionCookie } : {}),
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    const text = await response.text();
    let payload;
    try {
      payload = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`${label} returned non-JSON content: ${text.slice(0, 240)}`);
    }
    assert.equal(response.status, expectedStatus, `${label} returned HTTP ${response.status}: ${JSON.stringify(payload).slice(0, 500)}`);
    return { payload, response };
  } finally {
    clearTimeout(timer);
  }
}

async function test(label, callback) {
  const started = Date.now();
  try {
    await callback();
    results.push({ label, status: 'PASS', elapsedMs: Date.now() - started });
    console.log(`PASS  ${label}`);
  } catch (error) {
    results.push({ label, status: 'FAIL', elapsedMs: Date.now() - started, error: error.message });
    console.error(`FAIL  ${label}: ${error.message}`);
  }
}

async function establishReadOnlyDemoSession() {
  const { payload: users } = await request('demo users', '/api/users');
  const user = nonEmptyArray(users, 'demo users')[0];
  const actor = value(user, 'USERNAME', 'username');
  assert.equal(typeof actor, 'string', 'demo user has no username');
  const { response, payload } = await request('demo session', '/api/demo-session', {
    method: 'POST',
    body: { actor },
    headers: { origin, 'x-sled-demo-control': 'true' },
    expectedStatus: 201,
  });
  assert.equal(payload.ok, true, 'demo session was not issued');
  sessionCookie = responseCookies(response);
  assert.ok(sessionCookie.startsWith('sled_demo_session='), 'demo session cookie was not returned');
}

async function main() {
  await test('connection: API health queries ADB', async () => {
    const { payload } = await request('API health', '/api/health');
    assert.equal(payload.status, 'healthy');
    assert.equal(String(value(payload.database, 'STATUS', 'status')).toLowerCase(), 'connected');
  });

  await test('governed session can be established', establishReadOnlyDemoSession);

  const simpleGetTests = [
    ['seeded SLED demo status', '/api/demo/status', (body) => assert.equal(typeof body, 'object')],
    ['dashboard summary', '/api/dashboard/summary', (body) => assert.equal(typeof body, 'object')],
    ['SLED capacity KPIs', '/api/fulfillment/kpis', (body) => assert.equal(typeof body, 'object')],
    ['SLED network graph readiness', '/api/graph/readiness', (body) => assert.equal(typeof body, 'object')],
    ['SLED OML summary', '/api/ml/summary', (body) => assert.equal(typeof body, 'object')],
    ['Select AI profile metadata', '/api/selectai/profiles', (body) => {
      const profiles = nonEmptyArray(body.profiles, 'Select AI profiles');
      assert.ok(profiles.some((profile) => value(profile, 'name', 'NAME') === 'SLED_SELECTAI_V1'));
    }],
    ['Select AI curated schema', '/api/selectai/schema-objects', (body) => nonEmptyArray(body.objects, 'Select AI schema objects')],
    ['Select AI readiness', '/api/selectai/health', (body) => assert.equal(body.status, 'healthy')],
    ['native agent profiles', '/api/agents/profiles', (body) => assert.equal(typeof body, 'object')],
    ['native agent teams', '/api/agents/teams', (body) => {
      const teams = nonEmptyArray(body, 'native agent teams').map((team) => value(team, 'TEAM_NAME', 'team_name', 'name'));
      for (const team of ['RESIDENT_SIGNAL_TEAM', 'SERVICE_ACCESS_TEAM', 'PUBLIC_SERVICE_OPERATIONS_TEAM']) {
        assert.ok(teams.includes(team), `native agent team ${team} is missing`);
      }
    }],
    ['agent audit history', '/api/agents/actions?limit=3', (body) => assert.ok(Array.isArray(body), 'agent audit history must be an array')],
  ];

  for (const [label, path, assertion] of simpleGetTests) {
    await test(label, async () => {
      const { payload } = await request(label, path);
      assertion(payload);
    });
  }

  if (runAi) {
    await test('governed Ask Data SQL', async () => {
      const { payload } = await request('governed Ask Data SQL', '/api/selectai/runsql', {
        method: 'POST',
        body: { question: 'Which logistics terminals have the greatest capacity pressure?' },
        timeout: agentTimeoutMs,
      });
      assert.equal(typeof payload.sql, 'string', 'Ask Data did not return generated SQL');
      assert.ok(Array.isArray(payload.rows), 'Ask Data did not return a row array');
      assert.equal(payload.readOnly, true, 'Ask Data did not preserve the read-only boundary');
    });
  } else {
    results.push({ label: 'governed Ask Data SQL', status: 'SKIP', elapsedMs: 0 });
    console.log('SKIP  governed Ask Data SQL (use --include-ai to run one live Select AI request)');
  }

  if (runAgentChat) {
    await test('governed Agent Console advisory', async () => {
      const { payload } = await request('governed Agent Console advisory', '/api/agents/chat', {
        method: 'POST',
        body: {
          team: 'PUBLIC_SERVICE_OPERATIONS_TEAM',
          question: 'Show freight value by sled service category.',
        },
        timeout: agentTimeoutMs,
      });
      assert.equal(typeof payload.response, 'string', 'Agent Console returned no advisory response');
      assert.equal(payload.team, 'PUBLIC_SERVICE_OPERATIONS_TEAM', 'Agent Console did not use PUBLIC_SERVICE_OPERATIONS_TEAM');
      assert.equal(payload.readOnly, true, 'Agent Console did not preserve the read-only boundary');
      assert.equal(payload.advisory, true, 'Agent Console did not preserve the advisory boundary');
    });
  } else {
    results.push({ label: 'governed Agent Console advisory', status: 'SKIP', elapsedMs: 0 });
    console.log('SKIP  governed Agent Console advisory (use --include-agent-chat; it can add one proposed audit entry)');
  }

  const passed = results.filter((result) => result.status === 'PASS').length;
  const failed = results.filter((result) => result.status === 'FAIL');
  const skipped = results.filter((result) => result.status === 'SKIP').length;
  console.log(`\nSLED regression summary: ${passed} passed, ${failed.length} failed, ${skipped} skipped.`);
  if (failed.length) {
    console.log(JSON.stringify({ baseUrl, failed }, null, 2));
    process.exitCode = 1;
  } else {
    console.log('SLED_API_REGRESSION_OK');
  }
}

main().catch((error) => {
  console.error(`Fatal regression-runner error: ${error.stack || error.message}`);
  process.exitCode = 2;
});
